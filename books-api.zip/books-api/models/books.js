const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const bookSchema = new Schema({
    title: {
        type: String,
        required: true,
    },
    isbn: {
        type:  String,
        required: true,
    },
    pageCount: {
        type:  Number,
        required: true,
    },
    thumbnailUrl: {
        type: String,
        required: true,
    },
    shortDescription: {
        type: String,
        required: true,
    },
    longDescription: {
        type: String,
        required: true,
    },
    status:{
        type: String,
        required: true,
    },
    authors:[{
        type: String
    }],
    categories:[{
        type: String
    }]
});
bookSchema.index({'$**': 'text'});
var Books = mongoose.model('Book', bookSchema);

module.exports = Books;