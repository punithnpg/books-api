const express = require('express');
const bodyParser = require('body-parser');
const booksSearchRouter = express.Router();
const Books = require('../models/books');
booksSearchRouter.use(bodyParser.json());

booksSearchRouter.route('/:query')
    .all((req, res, next) => {

        res.statusCode = 200;
        res.setHeader('Content-Type', 'text/plain');
        next();
    })
    .get((req, res, next) => {

        var name = req.params.query;
        var name = name.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
        Books.find({title: new RegExp(name, 'i')})
            .then((books) => {
                res.statusCode = 200;
                res.setHeader('Content-Type', 'application/json')
                res.json(books);
            }, (err) => next(err))
            .catch((err) => next(err));
    })
    .post((req, res, next) => {
        res.statusCode = 403;
        res.end('POST operation not supported on /search');
    })
    .put((req, res, next) => {
        res.statusCode = 403;
        res.end('PUT operation not supported on /search');
    })
    .delete((req, res, next) => {
        res.statusCode = 403;
        res.end('DELETE operation not supported on /search');
    })

module.exports = booksSearchRouter;